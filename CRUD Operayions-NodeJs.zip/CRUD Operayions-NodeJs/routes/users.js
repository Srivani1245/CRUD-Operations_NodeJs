var express = require('express')
var app = express()
var ObjectId = require('mongodb').ObjectId

app.get('/',function(req,res,next) {	
	req.db.collection('users').find().sort({"_id": -1}).toArray(function(err,result)
	{
		if(err){
			req.flash('error',err)
			res.render('user/list',{
				title: 'User List', 
				data: ''
			})
		}
		else
		{
			res.render('user/list',
			{
				title: 'User Information', 
				data: result
			})
		}
	})
})

app.get('/add',function(req,res,next)
{	
	res.render('user/add',{
		title: 'Enter Details',
		name: '',
		email: ''		
	})
})

app.post('/add', function(req,res,next)
{	
	req.assert('name','Name mandatory').notEmpty()           
    req.assert('email','A valid email is manadatory').isEmail()  
    var errors = req.validationErrors()
    if(!errors){
		var user = {
			name: req.sanitize('name').escape().trim(),
			email: req.sanitize('email').escape().trim()
		}
				 
		req.db.collection('users').insert(user, function(err, result) {
			if (err) {
				req.flash('error', err)
				res.render('user/add',{
					title: 'Enter Details',
					name: user.name,
					email: user.email					
				})
			}else{				
				req.flash('success','Information added successfully!')
				res.redirect('/users')
			}
		})		
	}
	else{   
		var error_msg = ''
		errors.forEach(function(error){
			error_msg += error.msg +'<br>'
		})				
		req.flash('error', error_msg)		
        res.render('user/add', { 
            title: 'Enter Details',
            name: req.body.name,
            email: req.body.email
        })
    }
})

module.exports = app